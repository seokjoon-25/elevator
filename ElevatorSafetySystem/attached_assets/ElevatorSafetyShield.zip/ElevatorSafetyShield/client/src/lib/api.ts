import { apiRequest } from "./queryClient";
import type { InsertBulletinPost, InsertConsultation } from "@shared/schema";

export const api = {
  bulletin: {
    getPosts: (page: number = 1, limit: number = 10) => 
      fetch(`/api/bulletin?page=${page}&limit=${limit}`).then(res => res.json()),
    
    getPost: (id: number) => 
      fetch(`/api/bulletin/${id}`).then(res => res.json()),
    
    createPost: (data: InsertBulletinPost) => 
      apiRequest("POST", "/api/bulletin", data),
    
    verifyPassword: (id: number, password: string) =>
      apiRequest("POST", `/api/bulletin/${id}/verify`, { password }),
  },
  
  consultation: {
    create: (data: InsertConsultation) =>
      apiRequest("POST", "/api/consultation", data),
  },
};
