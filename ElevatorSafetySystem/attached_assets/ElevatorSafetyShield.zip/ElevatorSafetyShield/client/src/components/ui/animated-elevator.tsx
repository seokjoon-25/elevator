export function AnimatedElevator() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      <div className="elevator-shaft"></div>
      <div className="elevator-floors"></div>
      <div className="elevator-car">
        <div className="elevator-door"></div>
      </div>
    </div>
  );
}
