import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { insertConsultationSchema } from "@shared/schema";
import type { InsertConsultation } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Phone, Mail, Send, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { api } from "@/lib/api";

export function ContactForm() {
  const { toast } = useToast();

  const form = useForm<InsertConsultation>({
    resolver: zodResolver(insertConsultationSchema),
    defaultValues: {
      name: "",
      phone: "",
      elevatorNumber: "",
      elevatorAddress: "",
      message: "",
    },
  });

  const createConsultationMutation = useMutation({
    mutationFn: api.consultation.create,
    onSuccess: () => {
      toast({
        title: "상담 신청 완료",
        description: "상담 신청이 완료되었습니다. 빠른 시일 내에 연락드리겠습니다.",
      });
      form.reset();
    },
    onError: () => {
      toast({
        title: "오류",
        description: "상담 신청에 실패했습니다. 다시 시도해주세요.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertConsultation) => {
    createConsultationMutation.mutate(data);
  };

  return (
    <section id="contact" className="py-20 bg-gradient-to-br from-primary to-accent text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">상담 신청</h2>
          <p className="text-xl text-blue-100">전문 상담원이 최적의 보험상품을 제안해드립니다</p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Contact Form */}
          <Card className="bg-white/10 backdrop-blur-sm border-white/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Send className="h-5 w-5" />
                상담 신청
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">성명</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="성명을 입력해주세요" 
                            className="bg-white/20 border-white/30 text-white placeholder-white/70 focus:ring-white/50"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">연락처</FormLabel>
                        <FormControl>
                          <Input 
                            type="tel"
                            placeholder="010-0000-0000" 
                            className="bg-white/20 border-white/30 text-white placeholder-white/70 focus:ring-white/50"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="elevatorNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">승강기 번호</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="예: EL-2023-001" 
                            className="bg-white/20 border-white/30 text-white placeholder-white/70 focus:ring-white/50"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="elevatorAddress"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">승강기 소재지 주소</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="서울특별시 강남구..." 
                            className="bg-white/20 border-white/30 text-white placeholder-white/70 focus:ring-white/50"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">문의사항</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="궁금한 사항을 남겨주세요..." 
                            rows={4} 
                            className="bg-white/20 border-white/30 text-white placeholder-white/70 focus:ring-white/50 resize-none"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    className="w-full bg-white text-primary hover:bg-gray-100" 
                    disabled={createConsultationMutation.isPending}
                  >
                    <Send className="mr-2 h-4 w-4" />
                    {createConsultationMutation.isPending ? "신청 중..." : "상담 신청하기"}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
          
          {/* Contact Information */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold mb-6">빠른 상담 문의</h3>
              <p className="text-blue-100 text-lg mb-8">전화 또는 온라인으로 언제든 상담받으실 수 있습니다</p>
            </div>
            
            <div className="space-y-6">
              <div className="flex items-center space-x-4 p-6 bg-white/10 rounded-xl backdrop-blur-sm">
                <div className="bg-white text-primary w-12 h-12 rounded-xl flex items-center justify-center">
                  <Phone className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="font-semibold mb-1">전화 상담</h4>
                  <p className="text-blue-100">02-561-5599</p>
                  <p className="text-sm text-blue-200">평일 09:00 - 18:00</p>
                </div>
              </div>
              

              
              <div className="flex items-center space-x-4 p-6 bg-white/10 rounded-xl backdrop-blur-sm">
                <div className="bg-white text-primary w-12 h-12 rounded-xl flex items-center justify-center">
                  <Mail className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="font-semibold mb-1">이메일</h4>
                  <p className="text-blue-100">psj@ndongbu.com</p>
                  <p className="text-sm text-blue-200">24시간 내 답변</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white/10 p-6 rounded-xl backdrop-blur-sm">
              <h4 className="font-semibold mb-3">상담</h4>
              <ul className="space-y-2 text-blue-100">
                <li className="flex items-center"><CheckCircle className="mr-2 h-4 w-4" />맞춤형 보장 설계</li>
                <li className="flex items-center"><CheckCircle className="mr-2 h-4 w-4" />전문가 컨설팅</li>
                <li className="flex items-center"><CheckCircle className="mr-2 h-4 w-4" />신속한 가입 처리</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
