import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertBulletinPostSchema } from "@shared/schema";
import type { InsertBulletinPost } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Eye, MessageCircle, User, MapPin, Calendar, PenTool } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { api } from "@/lib/api";
import { queryClient } from "@/lib/queryClient";

export function BulletinBoard() {
  const { toast } = useToast();
  const [currentPage, setCurrentPage] = useState(1);
  
  const { data: bulletinData, isLoading } = useQuery({
    queryKey: ['/api/bulletin', currentPage],
    queryFn: () => api.bulletin.getPosts(currentPage, 10),
  });

  const form = useForm<InsertBulletinPost>({
    resolver: zodResolver(insertBulletinPostSchema),
    defaultValues: {
      elevatorNumber: "",
      name: "",
      address: "",
      content: "",
      password: "",
    },
  });

  const createPostMutation = useMutation({
    mutationFn: api.bulletin.createPost,
    onSuccess: () => {
      toast({
        title: "성공",
        description: "게시글이 성공적으로 등록되었습니다.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ['/api/bulletin'] });
    },
    onError: () => {
      toast({
        title: "오류",
        description: "게시글 등록에 실패했습니다.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertBulletinPost) => {
    createPostMutation.mutate(data);
  };

  return (
    <section id="bulletin" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">고객 게시판</h2>
          <p className="text-lg text-gray-600">승강기 정보 등록 및 문의사항을 남겨주세요</p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Bulletin Form */}
          <Card className="bg-gray-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <PenTool className="h-5 w-5" />
                새 글 작성
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="elevatorNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>승강기 번호</FormLabel>
                        <FormControl>
                          <Input placeholder="예: EL-2023-001" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>성명</FormLabel>
                        <FormControl>
                          <Input placeholder="홍길동" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="address"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>건물 주소</FormLabel>
                        <FormControl>
                          <Textarea placeholder="서울특별시 강남구..." rows={3} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="content"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>문의 내용</FormLabel>
                        <FormControl>
                          <Textarea placeholder="보험 관련 문의사항을 작성해주세요..." rows={4} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>글 비밀번호</FormLabel>
                        <FormControl>
                          <Input type="password" placeholder="글 조회/수정용 비밀번호" {...field} />
                        </FormControl>
                        <FormMessage />
                        <p className="text-sm text-gray-500">글 조회 및 수정 시 사용됩니다</p>
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={createPostMutation.isPending}
                  >
                    <PenTool className="mr-2 h-4 w-4" />
                    {createPostMutation.isPending ? "등록 중..." : "글 작성하기"}
                  </Button>
                </form>
              </Form>
            </CardContent>
          </Card>
          
          {/* Bulletin List */}
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-gray-900">최근 게시글</h3>
            
            {isLoading ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardContent className="pt-6">
                      <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                      <div className="h-3 bg-gray-200 rounded w-1/2 mb-4"></div>
                      <div className="h-3 bg-gray-200 rounded w-full"></div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : bulletinData?.posts?.length === 0 ? (
              <Card>
                <CardContent className="pt-6">
                  <p className="text-center text-gray-500">등록된 게시글이 없습니다.</p>
                </CardContent>
              </Card>
            ) : (
              bulletinData?.posts?.map((post: any) => (
                <Card key={post.id} className="hover:shadow-lg transition-all duration-200">
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex items-center space-x-3">
                        <Badge variant="default" className="bg-primary">
                          {post.elevatorNumber}
                        </Badge>
                        <h4 className="font-semibold text-gray-900">
                          {post.content.length > 20 ? `${post.content.slice(0, 20)}...` : post.content}
                        </h4>
                      </div>
                      <span className="text-sm text-gray-500">
                        {new Date(post.createdAt).toLocaleDateString('ko-KR')}
                      </span>
                    </div>
                    
                    <div className="text-sm text-gray-600 mb-3 flex items-center gap-4">
                      <span className="flex items-center gap-1">
                        <User className="h-3 w-3" />
                        {post.name}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        {post.address.length > 15 ? `${post.address.slice(0, 15)}...` : post.address}
                      </span>
                    </div>
                    
                    <p className="text-gray-700 mb-4">
                      {post.content.length > 60 ? `${post.content.slice(0, 60)}...` : post.content}
                    </p>
                    
                    <Separator className="my-4" />
                    
                    <div className="flex justify-between items-center">
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <span className="flex items-center gap-1">
                          <Eye className="h-3 w-3" />
                          {post.views}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          {new Date(post.createdAt).toLocaleDateString('ko-KR')}
                        </span>
                      </div>
                      <Button variant="link" size="sm" className="text-primary hover:text-blue-700">
                        상세보기
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
            
            {/* Pagination */}
            {bulletinData && bulletinData.total > 10 && (
              <div className="flex justify-center mt-8">
                <div className="flex space-x-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                    disabled={currentPage === 1}
                  >
                    이전
                  </Button>
                  {[...Array(Math.ceil(bulletinData.total / 10))].map((_, i) => (
                    <Button
                      key={i + 1}
                      variant={currentPage === i + 1 ? "default" : "outline"}
                      size="sm"
                      onClick={() => setCurrentPage(i + 1)}
                    >
                      {i + 1}
                    </Button>
                  ))}
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setCurrentPage(prev => Math.min(Math.ceil(bulletinData.total / 10), prev + 1))}
                    disabled={currentPage === Math.ceil(bulletinData.total / 10)}
                  >
                    다음
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
