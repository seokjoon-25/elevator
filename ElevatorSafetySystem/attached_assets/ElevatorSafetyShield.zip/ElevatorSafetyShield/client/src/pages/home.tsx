import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AnimatedElevator } from "@/components/ui/animated-elevator";

import { ContactForm } from "@/components/ui/contact-form";
import { 
  Building, 
  Shield, 
  Users, 
  Hammer, 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  CheckCircle,
  Calculator,
  PhoneCall,
  Info,
  MessageCircle
} from "lucide-react";

export default function HomePage() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="bg-primary text-white p-2 rounded-lg">
                <Building className="h-6 w-6" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">드림포레스트 보험대리점</h1>
                <p className="text-sm text-gray-600">승강기사고배상책임보험 전문</p>
              </div>
            </div>
            <div className="flex items-center space-x-2 text-gray-700">
              <Phone className="h-4 w-4" />
              <span className="font-medium">02-561-5599</span>
            </div>
            <nav className="hidden md:flex space-x-6">
              <button 
                onClick={() => scrollToSection('insurance-info')} 
                className="text-gray-700 hover:text-primary transition-colors"
              >
                보험안내
              </button>
              <button 
                onClick={() => scrollToSection('agency-info')} 
                className="text-gray-700 hover:text-primary transition-colors"
              >
                대리점정보
              </button>

              <button 
                onClick={() => scrollToSection('contact')} 
                className="text-gray-700 hover:text-primary transition-colors"
              >
                상담신청
              </button>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="elevator-bg bg-gradient-to-br from-primary to-accent text-white py-20 relative min-h-screen flex items-center">
        <AnimatedElevator />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              승강기사고<br />
              배상책임보험
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-blue-100">
              안전한 승강기 운영을 위한 필수 보험<br />
              전문적인 상담과 맞춤형 보장을 제공합니다
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={() => scrollToSection('contact')}
                className="bg-white text-primary px-8 py-4 text-lg hover:bg-gray-100"
                size="lg"
              >
                <PhoneCall className="mr-2 h-5 w-5" />
                상담 신청하기
              </Button>

            </div>
          </div>
        </div>
      </section>

      {/* Insurance Information */}
      <section id="insurance-info" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">승강기사고배상책임보험이란?</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              승강기 운행 중 발생할 수 있는 사고로 인한 배상책임을 보장하는 필수 보험입니다
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <Card className="hover:shadow-lg transition-all duration-300">
              <CardHeader>
                <div className="bg-primary text-white w-16 h-16 rounded-xl flex items-center justify-center mb-4">
                  <Shield className="h-8 w-8" />
                </div>
                <CardTitle>법정의무보험</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">승강기안전법에 따른 의무가입 보험으로 법적 요구사항을 충족합니다</p>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-all duration-300">
              <CardHeader>
                <div className="bg-accent text-white w-16 h-16 rounded-xl flex items-center justify-center mb-4">
                  <Users className="h-8 w-8" />
                </div>
                <CardTitle>인명피해 보장</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">승강기 사고로 인한 사망, 부상 등 인명피해에 대한 배상책임을 보장합니다</p>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-all duration-300">
              <CardHeader>
                <div className="bg-primary text-white w-16 h-16 rounded-xl flex items-center justify-center mb-4">
                  <Hammer className="h-8 w-8" />
                </div>
                <CardTitle>재물손해 보장</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">승강기 사고로 인한 재물 손해에 대한 배상책임을 보장합니다</p>
              </CardContent>
            </Card>
          </div>

          {/* Insurance Timing */}
          <Card className="bg-gradient-to-r from-blue-50 to-indigo-50">
            <CardHeader>
              <CardTitle className="text-2xl">보험가입 시기</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                <li className="flex items-start"><CheckCircle className="text-green-500 mr-3 h-5 w-5 mt-0.5" />법 제28조제1항에 따른 설치검사를 받은 날</li>
                <li className="flex items-start"><CheckCircle className="text-green-500 mr-3 h-5 w-5 mt-0.5" />관리주체가 변경된 경우 그 변경된 날</li>
                <li className="flex items-start"><CheckCircle className="text-green-500 mr-3 h-5 w-5 mt-0.5" />책임보험의 만료일 이내</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Agency Information */}
      <section id="agency-info" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">보험대리점 정보</h2>
            <p className="text-lg text-gray-600">승강기보험 전문 대리점으로 최적의 보험상품을 제공합니다</p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Company Image */}
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
                alt="신뢰보험대리점 사무실" 
                className="rounded-2xl shadow-2xl w-full h-auto"
              />
              <div className="absolute -bottom-6 -right-6 bg-primary text-white p-6 rounded-xl shadow-lg">
                <div className="text-center">
                  <div className="text-2xl font-bold">Since</div>
                  <div className="text-sm">2013</div>
                </div>
              </div>
            </div>
            
            {/* Company Info */}
            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">드림포레스트 보험대리점</h3>
                <p className="text-gray-600 mb-6">
                  10년이 넘는 경험을 바탕으로 승강기사고배상책임보험 전문 서비스를 제공하는 대리점입니다. 
                  고객의 안전과 보장을 최우선으로 하며, 맞춤형 보험상담을 통해 최적의 보험료와 보장내용을 제안드립니다.
                </p>
              </div>
              
              <div className="grid sm:grid-cols-2 gap-6">
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center mb-3">
                      <Building className="text-primary mr-3 h-5 w-5" />
                      <h4 className="font-semibold">상호명</h4>
                    </div>
                    <p className="text-gray-700">드림포레스트 보험대리점</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center mb-3">
                      <Phone className="text-primary mr-3 h-5 w-5" />
                      <h4 className="font-semibold">전화번호</h4>
                    </div>
                    <p className="text-gray-700">02-561-5599</p>
                  </CardContent>
                </Card>
                

                
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center mb-3">
                      <Mail className="text-primary mr-3 h-5 w-5" />
                      <h4 className="font-semibold">이메일</h4>
                    </div>
                    <p className="text-gray-700">psj@ndongbu.com</p>
                  </CardContent>
                </Card>
                
                <Card className="sm:col-span-2">
                  <CardContent className="pt-6">
                    <div className="flex items-center mb-3">
                      <MapPin className="text-primary mr-3 h-5 w-5" />
                      <h4 className="font-semibold">주소</h4>
                    </div>
                    <p className="text-gray-700">서울특별시 강남구 테헤란로 116, 6층</p>
                  </CardContent>
                </Card>
                
                <Card className="sm:col-span-2">
                  <CardContent className="pt-6">
                    <div className="flex items-center mb-3">
                      <Clock className="text-primary mr-3 h-5 w-5" />
                      <h4 className="font-semibold">영업시간</h4>
                    </div>
                    <p className="text-gray-700">평일 09:00 - 18:00 (토요일 09:00 - 13:00, 일요일 휴무)</p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>



      {/* Contact Section */}
      <ContactForm />

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="bg-primary text-white p-2 rounded-lg">
                  <Building className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">드림포레스트 보험대리점</h3>
                  <p className="text-gray-400">승강기사고배상책임보험 전문</p>
                </div>
              </div>
              <p className="text-gray-300 mb-4">
                10년이 넘는 경험으로 고객의 안전과 보장을 최우선으로 하는 보험대리점입니다. 
                승강기사고배상책임보험 전문 서비스를 통해 최적의 보험상품을 제공합니다.
              </p>
              <div className="flex space-x-4">
                <Button variant="ghost" size="icon" className="bg-yellow-500 hover:bg-yellow-600 text-black">
                  <MessageCircle className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">빠른 링크</h4>
              <ul className="space-y-2 text-gray-300">
                <li>
                  <button 
                    onClick={() => scrollToSection('insurance-info')} 
                    className="hover:text-white transition-colors"
                  >
                    보험안내
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => scrollToSection('agency-info')} 
                    className="hover:text-white transition-colors"
                  >
                    대리점정보
                  </button>
                </li>

                <li>
                  <button 
                    onClick={() => scrollToSection('contact')} 
                    className="hover:text-white transition-colors"
                  >
                    상담신청
                  </button>
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">연락처</h4>
              <ul className="space-y-2 text-gray-300">
                <li className="flex items-center"><Phone className="mr-2 h-4 w-4" />02-561-5599</li>
                <li className="flex items-center"><Mail className="mr-2 h-4 w-4" />psj@ndongbu.com</li>
                <li className="flex items-center"><MapPin className="mr-2 h-4 w-4" />서울 강남구 테헤란로 116</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-700 pt-8 text-center text-gray-400">
            <div className="space-y-2">
              <p>&copy; 2025 드림포레스트 보험대리점. All rights reserved. | 승강기사고배상책임보험 전문대리점</p>
              <p className="text-sm">대표 : 박석준 | 대리점 등록번호 : 2013080138 | 사업자등록번호 : 220-91-21382</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
