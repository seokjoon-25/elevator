import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const bulletinPosts = pgTable("bulletin_posts", {
  id: serial("id").primaryKey(),
  elevatorNumber: text("elevator_number").notNull(),
  name: text("name").notNull(),
  address: text("address").notNull(),
  content: text("content").notNull(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  views: integer("views").default(0).notNull(),
});

export const consultations = pgTable("consultations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  elevatorNumber: text("elevator_number"),
  elevatorAddress: text("elevator_address"),
  message: text("message"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertBulletinPostSchema = createInsertSchema(bulletinPosts).pick({
  elevatorNumber: true,
  name: true,
  address: true,
  content: true,
  password: true,
});

export const insertConsultationSchema = createInsertSchema(consultations).pick({
  name: true,
  phone: true,
  elevatorNumber: true,
  elevatorAddress: true,
  message: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type BulletinPost = typeof bulletinPosts.$inferSelect;
export type InsertBulletinPost = z.infer<typeof insertBulletinPostSchema>;

export type Consultation = typeof consultations.$inferSelect;
export type InsertConsultation = z.infer<typeof insertConsultationSchema>;
