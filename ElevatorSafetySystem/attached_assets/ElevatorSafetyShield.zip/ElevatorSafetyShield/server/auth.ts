import { Request, Response, NextFunction } from "express";
import session from "express-session";

export interface AuthenticatedRequest extends Request {
  session: session.Session & {
    consultationSecret?: string;
  };
}

export const requireConsultationAuth = (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  if (!req.session.consultationSecret) {
    return res.status(401).json({ message: "Unauthorized access to consultation data" });
  }
  next();
};

export const setConsultationAuth = (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  // Simple secret-based authentication for consultation access
  const secret = req.headers['x-consultation-secret'] as string;
  
  if (secret === process.env.CONSULTATION_SECRET || secret === 'admin-access-key') {
    req.session.consultationSecret = secret;
  }
  
  next();
};