import { users, bulletinPosts, consultations, type User, type InsertUser, type BulletinPost, type InsertBulletinPost, type Consultation, type InsertConsultation } from "@shared/schema";
import bcrypt from "bcryptjs";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getBulletinPosts(page?: number, limit?: number): Promise<{ posts: BulletinPost[], total: number }>;
  getBulletinPost(id: number): Promise<BulletinPost | undefined>;
  createBulletinPost(post: InsertBulletinPost): Promise<BulletinPost>;
  verifyBulletinPostPassword(id: number, password: string): Promise<boolean>;
  incrementBulletinPostViews(id: number): Promise<void>;
  
  createConsultation(consultation: InsertConsultation): Promise<Consultation>;
  getConsultations(): Promise<Consultation[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private bulletinPosts: Map<number, BulletinPost>;
  private consultations: Map<number, Consultation>;
  private currentUserId: number;
  private currentPostId: number;
  private currentConsultationId: number;

  constructor() {
    this.users = new Map();
    this.bulletinPosts = new Map();
    this.consultations = new Map();
    this.currentUserId = 1;
    this.currentPostId = 1;
    this.currentConsultationId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    const user: User = { 
      ...insertUser, 
      id, 
      password: hashedPassword 
    };
    this.users.set(id, user);
    return user;
  }

  async getBulletinPosts(page: number = 1, limit: number = 10): Promise<{ posts: BulletinPost[], total: number }> {
    const allPosts = Array.from(this.bulletinPosts.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    const total = allPosts.length;
    const startIndex = (page - 1) * limit;
    const posts = allPosts.slice(startIndex, startIndex + limit);
    
    return { posts, total };
  }

  async getBulletinPost(id: number): Promise<BulletinPost | undefined> {
    return this.bulletinPosts.get(id);
  }

  async createBulletinPost(insertPost: InsertBulletinPost): Promise<BulletinPost> {
    const id = this.currentPostId++;
    const hashedPassword = await bcrypt.hash(insertPost.password, 10);
    const post: BulletinPost = {
      ...insertPost,
      id,
      password: hashedPassword,
      createdAt: new Date(),
      views: 0,
    };
    this.bulletinPosts.set(id, post);
    return post;
  }

  async verifyBulletinPostPassword(id: number, password: string): Promise<boolean> {
    const post = this.bulletinPosts.get(id);
    if (!post) return false;
    return bcrypt.compare(password, post.password);
  }

  async incrementBulletinPostViews(id: number): Promise<void> {
    const post = this.bulletinPosts.get(id);
    if (post) {
      post.views++;
      this.bulletinPosts.set(id, post);
    }
  }

  async createConsultation(insertConsultation: InsertConsultation): Promise<Consultation> {
    const id = this.currentConsultationId++;
    const consultation: Consultation = {
      ...insertConsultation,
      id,
      createdAt: new Date(),
      elevatorNumber: insertConsultation.elevatorNumber || null,
      elevatorAddress: insertConsultation.elevatorAddress || null,
      message: insertConsultation.message || null,
    };
    this.consultations.set(id, consultation);
    return consultation;
  }

  async getConsultations(): Promise<Consultation[]> {
    return Array.from(this.consultations.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
}

export const storage = new MemStorage();
