import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertBulletinPostSchema, insertConsultationSchema } from "@shared/schema";
import { z } from "zod";
import { requireConsultationAuth, setConsultationAuth, type AuthenticatedRequest } from "./auth";

export async function registerRoutes(app: Express): Promise<Server> {
  // Apply consultation auth middleware
  app.use(setConsultationAuth);
  // Bulletin Board Routes
  app.get("/api/bulletin", async (req, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;
      
      const result = await storage.getBulletinPosts(page, limit);
      
      // Remove password from response
      const safePosts = result.posts.map(post => {
        const { password, ...safePost } = post;
        return {
          ...safePost,
          name: post.name.charAt(0) + '*'.repeat(post.name.length - 1), // Mask name for privacy
        };
      });
      
      res.json({ posts: safePosts, total: result.total });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bulletin posts" });
    }
  });

  app.get("/api/bulletin/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const post = await storage.getBulletinPost(id);
      
      if (!post) {
        return res.status(404).json({ message: "Post not found" });
      }
      
      await storage.incrementBulletinPostViews(id);
      
      const { password, ...safePost } = post;
      res.json({
        ...safePost,
        name: post.name.charAt(0) + '*'.repeat(post.name.length - 1),
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bulletin post" });
    }
  });

  app.post("/api/bulletin", async (req, res) => {
    try {
      const validation = insertBulletinPostSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid input data",
          errors: validation.error.issues 
        });
      }
      
      const post = await storage.createBulletinPost(validation.data);
      const { password, ...safePost } = post;
      
      res.status(201).json(safePost);
    } catch (error) {
      res.status(500).json({ message: "Failed to create bulletin post" });
    }
  });

  app.post("/api/bulletin/:id/verify", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { password } = req.body;
      
      if (!password) {
        return res.status(400).json({ message: "Password is required" });
      }
      
      const isValid = await storage.verifyBulletinPostPassword(id, password);
      res.json({ valid: isValid });
    } catch (error) {
      res.status(500).json({ message: "Failed to verify password" });
    }
  });

  // Consultation Routes
  app.post("/api/consultation", async (req, res) => {
    try {
      const validation = insertConsultationSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Invalid input data",
          errors: validation.error.issues 
        });
      }
      
      const consultation = await storage.createConsultation(validation.data);
      // Only return success message, not the actual data for security
      res.status(201).json({ message: "상담 신청이 완료되었습니다." });
    } catch (error) {
      res.status(500).json({ message: "Failed to create consultation request" });
    }
  });

  // Protected route to get consultations (admin only)
  app.get("/api/consultations", requireConsultationAuth, async (req: AuthenticatedRequest, res) => {
    try {
      const consultations = await storage.getConsultations();
      res.json(consultations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch consultations" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
